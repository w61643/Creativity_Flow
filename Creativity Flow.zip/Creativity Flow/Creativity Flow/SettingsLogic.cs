﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Creativity_Flow
{
    public class SettingsLogic
    {
        
        public int timeBeforeStart;
        public int timeBeforeErasing;
        public int erasingSpeed;
        public int stopPermissionTime;



        /// <summary>
        ///  Check if text is correct 
        /// </summary>
        /// <param name="var">
        /// The variable.
        /// </param>
        /// <param name="senderText">
        /// The sender text.
        /// </param>
        /// <returns>
        /// TRUE if text is CORRECT.<br />FALSE if text is NOT CORRECT.
        /// </returns>
        /// <exception cref="Exception"></exception>
        public static bool TextCheck(ref int var, string senderText)
        {
            if (senderText != null)
            {
                try
                {
                    var = Int32.Parse(senderText);
                    if (var == 0)
                    {
                        throw new Exception();
                    }
                    return true;
                }
                catch
                {
                    var = 0;
                    return false;
                }
            }
            return false;
        }

        /// <summary>
        /// Check if applyB could be active
        /// </summary>
        /// <param name="timeBeforeStart">
        /// The time before start.
        /// </param>
        /// <param name="timeBeforeErasing">
        /// The time before erasing.
        /// </param>
        /// <param name="erasingSpeed">
        /// The erasing speed.
        /// </param>
        /// <param name="stopPermissionTime">
        /// The stop permission time.
        /// </param>
        /// <returns>
        /// TRUE if applyB COULD be active .<br />FALSE if applyB COULD NOT be active .
        /// </returns>
        public static bool ApplyActivation(ref int timeBeforeStart, ref int timeBeforeErasing, ref int erasingSpeed, ref int stopPermissionTime)
        {
            if (timeBeforeStart == 0 || timeBeforeErasing == 0 || erasingSpeed == 0 || stopPermissionTime == 0) { return false; }
            else { return true; }
        }
    }
}
