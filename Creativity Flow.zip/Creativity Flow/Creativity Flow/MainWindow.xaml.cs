﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading; ///< for making threads
using System.Threading.Tasks;
using System.Timers; ///< for simple timers
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.ComponentModel;
using System.Net;
using System.Runtime.InteropServices; ///< for using *.ini files from lib kernel32.dll
using Microsoft.VisualBasic.CompilerServices;


namespace Creativity_Flow
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // program 
        // variables
        bool textBoxChanged; ///< to track if data has changed
        bool lastChangeAfterSave = false; ///< track if we changed something after last save
        bool workState = false; ///< say us when we are already working
        bool stopState = false; ///< begin stop process for work_Thread

        
        Thread workThread; ///< used for collaboration work with user to not interfere him with UI blocking

        FileStream fileStream; ///< always contents the current file
        string activeFileFullName; ///< used to track what file is opened now // TODO OPTIMIZE


        public static string profile; ///< contain current profile name for all classes
        public static string profilesSettingsPath = "./profiles_settings.ini";
        public static string programSettingsPath = "./program_settings.ini";



        // global settings variables
        //string colorTheme; // TODO NORMAL color themes


        // profile settings variables // TODO NORMAL set default settings here?
        bool startType; ///< set using of start with first character if true or prestart count if false // TODO LOW look for more ideas
        //
        int timeBeforeStart; ///< set time in seconds we have before starting work with prestart count
        System.Timers.Timer preStartTimer; ///< count time before starting work with prestart count
        int preStartTimerState = 0; ///< var to count timer ticks

        System.Timers.Timer lastChangeTimer = null; ///< count time passed after last change in textBox
        int lastChangeTimerState = 0; ///< var to count timer ticks

        bool erasingModeSwitch = true; ///< activate erasing mode
        int timeBeforeErasing = 2; ///< set time in seconds we have before erasing text
        string erasingType = "symbol"; ///< set to erase by symbol, word, sentence, paragraph or all holy... text // TODO NORMAL make all types
        string erasingFunction = "linear"; ///< set linear or other erasing function // TODO NORMAL erasing functions
        int erasingSpeed = 1000; ///< set basic speed parameter in MILIseconds. for example: for line function erase one erasingType every erasingSpeed
        System.Timers.Timer realErasingSpeedTimer = null; ///< count time to erase
        int realErasingSpeedTimerState = 0; ///< var to count timer ticks
        //TextRange erasingRange;

        bool soundSignalSwitch; // attracts your attention or play some motivation audio // TODO NORMAL sound signals
        bool visualSignalSwitch; // attracts attention // TODO NORMAL visual signals
        bool backspaceSwitch; // turns backspace off // TODO NORMAL backspace switch
        bool pointerSwitch; // block your pointer in the end of the text // TODO NORMAL block for text pointer
        bool hiderSwitch; // hide some head part of text and block slider to prevent reading // TODO NORMAL text hider

        bool emergencyStoperSwitch; // give you one more chance to turn off an iron // TODO NORMAL emergency stop // TODO LOW make penalty for emergency stop
        bool emergencyHiderSwitch; // hide text while you turning your iron off // TODO NORMAL emergency stop hider
        bool emergencyStopLimiterSwitch; // activate limit of emergency stops // TODO NORMAL emergency stop limiter
        int emergencyStopLimit; // set limit of emergency stops
        bool emergencyStopPermissionTimerSwitch; // activate time pause for next use of emergency stop // TODO NORMAL emergency stop timer
        int emergencyStopPermissionTime; // set time to wait for next emergency stop

        bool stopPermissionTimerSwitch; ///< activate help to work hard for minimum seted time. you can not stop and save work before this time is gone // TODO NORMAL stop permission metod
        long stopPermissionTime; ///< set minimum time you need to work hard
        System.Timers.Timer stopPermissionTimer = null; ///< time passed after last change in textBox
        int stopPermissionTimerState = 0; ///< var to count timer ticks

        bool autoSaveAfterStopPermissionSwitch; // autosave after stopPermissionTime is up // TODO NORMAL auto save after stop permision time is gone


        /// using *.ini stuff metods. need to save settings with program to make it portable // maybe i will use it in settings window // TODO make settings saver
        [DllImport("kernel32.dll", EntryPoint = "GetPrivateProfileString")] // to get value from *.ini file
        private static extern int GetPrivateString(string section, string key, string def, StringBuilder buffer, int size, string path); // use: def = null, size = 1024, path = "./profiles.ini"; buffer.ToString() give value for us
        /// using *.ini stuff metods. need to save settings with program to make it portable
        [DllImport("kernel32.dll", EntryPoint = "WritePrivateProfileString")]  // to set value in *.ini file
        private static extern int WritePrivateString(string section, string key, string str, string path);


        // TODO NORMAL look for focusing on textBox all over the time



        /// <summary>
        /// Initializes a new instance of the <see cref="MainWindow" /> class.
        /// <br />Ask to open last opened file or to make empty one.<br />Set program variables with values from ini files by <see cref="SetProfileVariables" /> method.
        /// </summary>
        /// <seealso cref="SetProfileVariables" />
        public MainWindow()
        {
            InitializeComponent();

            if (File.Exists(programSettingsPath))
            {                
                StringBuilder buffer = new StringBuilder(255);


                GetPrivateString("ProfileSettings", "activeProfile", null, buffer, 255, programSettingsPath); // TODO HIGH what if there is no profile with this name?

                if (buffer.ToString() != "") { profile = buffer.ToString(); }
                else { profile = "Default"; }


                GetPrivateString("OpenedFiles", "activeFile", null, buffer, 255, programSettingsPath);
                                
                if (buffer.ToString() != "" && File.Exists(buffer.ToString()))
                {
                    MessageBoxResult result = MessageBox.Show("Do you want to open last opened file?", "Last opened file", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    switch (result)
                    {
                        case MessageBoxResult.Yes:
                            {
                                activeFileFullName = buffer.ToString();

                                break;
                            }
                        case MessageBoxResult.No:
                            {
                                activeFileFullName = "./temp.txt";

                                break;
                            }
                    }                    
                }
                else
                {
                    activeFileFullName = "./temp.txt";
                }

                // open or create // TODO NORMAL try to make a setting for this
                fileStream = new FileStream(activeFileFullName, FileMode.OpenOrCreate);
                TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                range.Load(fileStream, DataFormats.Text);
            }
            else { MessageBox.Show("Program settings file NOT found!"); }


            //SetProgramVariables();

            SetProfileVariables();




        }

        /////////////////////////////////////////////////////////////////////////////////////////// program state
        /*
        private void TextBox_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e) // does not work as expected
        {
            textBox_DataContextChanged = true;
        }
        */

        /// <summary>
        /// Handles the KeyUp event of the textBox control to track of changing textBox.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="KeyEventArgs" /> instance containing the event data.
        /// </param>
        private void TextBox_KeyUp(object sender, KeyEventArgs e)
        {
            textBoxChanged = true;
            lastChangeAfterSave = true;
            lastChangeTimerState = 0; // start count from 0 ,if we stop typing // TODO NORMAL move to work trade or not?
        }
        /*
        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            textBox.Focus(); // crash
        }
        */
        /////////////////////////////////////////////////////////////////////////////////////////// comands
        ///////////////////////////////////////// interfaces
        public interface ICommand // for basic comands
        {
            event EventHandler CanExecuteChanged;
            void Execute(object parameter);
            bool CanExecute(object parameter);
        }

        public interface ICommandSource // for basic comands
        {
            ICommand Command { get; }
            object CommandParameter { get; }
            IInputElement CommandTarget { get; }
        }

        ///////////////////////////////////////// executes

        /// <summary>
        /// Creates new temporary file and openes it in textBox.<br />In case some file already was opened and changed it use <see cref="AskToSaveIfNeedTo" /> method.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.
        /// </param>
        private void NewFile_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (AskToSaveIfNeedTo())
            {
                // close old filestream if need
                if (fileStream != null)
                {
                    fileStream.Close();
                }

                textBox.Document.Blocks.Clear();


                activeFileFullName = "./temp.txt";


                // open and load file // TODO NORMAL save to temp all active files to prevent losing data
                fileStream = new FileStream(activeFileFullName, FileMode.Create);
                TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                range.Load(fileStream, DataFormats.Text);

                lastChangeAfterSave = false;
            }
        }

        /// <summary>
        /// Opens dialog for opening some file in textBox.<br />In case some file already was opened and changed it use <see cref="AskToSaveIfNeedTo" /> method.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenFile_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (AskToSaveIfNeedTo())
            { // TODO NORMAL MessageBox.Show("file saved");
                // open and load file
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "Text files | *.txt";
                if (dialog.ShowDialog() == true)
                {
                    // close old filestream if need
                    if (fileStream != null)
                    {
                        fileStream.Close();
                    }

                    textBox.Document.Blocks.Clear();

                    activeFileFullName = dialog.FileName;

                    fileStream = new FileStream(activeFileFullName, FileMode.Open);
                    TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                    range.Load(fileStream, DataFormats.Text);
                }

                lastChangeAfterSave = false;
            }


        }

        /// <summary>
        /// Handles the Executed event of the saveFile control. Using <see cref="SaveToActiveFile" /> method save text in textBox in opened file or show SaveFileDialog if file is temporary.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.
        /// </param>
        private void SaveFile_Executed(object sender, ExecutedRoutedEventArgs e) // TODO NORMAL this is used in AskToSaveIfNeedTo
        {
            //textBox.IsEnabled = true; // test

            if (activeFileFullName != "./temp.txt") // TODO NORMAL find way to use SaveAs_Executed // TODO HIGH check if it works right
            {
                // save file
                //TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                //range.Save(fileStream, DataFormats.Text);
                SaveToActiveFile();

                lastChangeAfterSave = false;
            }
            else
            {
                // save file as // TODO LOW make proposition for default or last name and path
                SaveFileDialog dialog = new SaveFileDialog();
                dialog.Filter = "Text files | *.txt";
                if (dialog.ShowDialog() == true) // TODO NORMAL check how does it work
                {
                    activeFileFullName = dialog.FileName;

                    //fileStream = new FileStream(activeFileFullName, FileMode.Create);
                    //TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                    //range.Save(fileStream, DataFormats.Text);
                    //range.ToString();
                    SaveToActiveFile();

                    lastChangeAfterSave = false;
                }
            }

            //textBox.IsEnabled = false; // test
        }


        /// <summary>
        /// Handles the Executed event of the SaveFileAs control. Using <see cref="SaveToActiveFile" /> method with SaveFileDialog to save text in textBox.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.
        /// </param>
        private void SaveFileAs_Executed(object sender, ExecutedRoutedEventArgs e) // TODO NORMAL this is used in SaveFile_Executed and partly in AskToSaveIfNeedTo
        {
            // save file as // TODO LOW make proposition for default or last name and path
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "Text files | *.txt";
            if (dialog.ShowDialog() == true) // TODO NORMAL check how does it work
            {
                activeFileFullName = dialog.FileName;

                //fileStream = new FileStream(activeFileFullName, FileMode.Create);
                //TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                //range.Save(fileStream, DataFormats.Text);
                SaveToActiveFile();

                lastChangeAfterSave = false;
            }            
        }


        /// <summary>
        /// Handles the Executed event of the Quit control.
        /// Just one more way to close the app.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.
        /// </param>
        private void Quit_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        /*
        private void DefaultProfile_Click(object sender, RoutedEventArgs e) // TODO NORMAL modify
        {
            if (File.Exists(profilesSettingsPath))
            {
                StringBuilder buffer = new StringBuilder(255);

                profile = "Default";

                WritePrivateString("ProfileSettings", "activeProfile", profile, programSettingsPath);
            }
        }

        private void Profile1_Click(object sender, RoutedEventArgs e) // TODO NORMAL modify
        {
            if (File.Exists(profilesSettingsPath))
            {
                StringBuilder buffer = new StringBuilder(255);

                profile = "Profile1";
                WritePrivateString("ProfileSettings", "activeProfile", profile, programSettingsPath);
            }
        }
        */

        /// <summary>
        /// Handles the Executed event of the Settings control.
        /// Opens SettingsWindow.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.
        /// </param>
        private void Settings_Executed(object sender, ExecutedRoutedEventArgs e) // open settings window
        {
            SettingsWindow settingsWindow = new SettingsWindow();
            settingsWindow.Owner = this; // this relation will help to exchange data easyly // AhahAHA, I thought so)))
            settingsWindow.Closed += new EventHandler(SettingsWindow_Closed); // used to update changed settings
            settingsWindow.Show();
        }


        /// <summary>
        /// Handles the Executed event of the Start control.
        /// Prepare program and start workThread (<see cref="Work" /> method) for editing process.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.
        /// </param>
        private void Start_Executed(object sender, ExecutedRoutedEventArgs e) // start work process
        {
            start.IsEnabled = false;

            if (stopPermissionTimerSwitch == false) { stopB.IsEnabled = true; }

            if (startType == true)
            {
                    textBox.IsEnabled = true;
                    textBox.Focus();
            }

            stopState = false;

            
            workThread = new Thread(Work);
            workThread.IsBackground = true;
            workThread.Start();
        }


        /// <summary>
        /// Handles the Executed event of the Stop control.
        /// Prepare program to stop editing process, stops timers, stops workThread (<see cref="Work" /> method).
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="ExecutedRoutedEventArgs" /> instance containing the event data.
        /// </param>
        private void Stop_Executed(object sender, ExecutedRoutedEventArgs e) // stop work process
        {
            stopB.IsEnabled = false;

            start.IsEnabled = true;

            textBox.IsEnabled = false;

            stopState = true; ///< stops workThread

            workState = false;


            //workThread.Abort(); // TODO HIGH check if it works properly
            //workThread.Interrupt();
            //chillThread.Resume(); // TODO HIGH find some way to do it

            PreStartTimerStop();
            LastChangeTimerStop();
            RealErasingSpeedTimerStop();
            StopPermissionTimerStop();


            // TODO HIGH here we should stop work process right and save what we need
        }

        /////////////////////////////////////////////////////////////////////////////////////////// other

        // TODO NORMAL auto save to temp

        ///////////////////////////////////////// timers // TODO NORMAL try to simplefy with (sender as System.Timers.Timer). ... to identify variable // TODO NORMAL think about upload
        //////////////// prestart timer

        /// <summary>
        /// Start "start countdown" timer.
        /// </summary>
        private void PreStartTimerStart()
        {
            preStartTimerState = 0;
            preStartTimer = new System.Timers.Timer();
            preStartTimer.Interval = 1000;
            preStartTimer.Elapsed += new ElapsedEventHandler(PreStartTimerTick); // timers tick
            preStartTimer.Enabled = true; // starts timer
        }

        private void PreStartTimerTick(object sender, EventArgs e)
        {
            preStartTimerState++;
        }

        private void PreStartTimerStop()
        {
            if (preStartTimer != null) { preStartTimer.Enabled = false; } // stops timer
        }

        //////////////// last change timer

        /// <summary>
        ///  Start timer that count time after last change in textBox was made.
        /// </summary>
        private void LastChangeTimerStart()
        {
            lastChangeTimerState = 0;
            lastChangeTimer = new System.Timers.Timer();
            lastChangeTimer.Interval = 1000;
            lastChangeTimer.Elapsed += new ElapsedEventHandler(LastChangeTimerTick); // timers tick
            lastChangeTimer.Enabled = true; // starts timer
        }

        private void LastChangeTimerTick(object sender, EventArgs e)
        {
            lastChangeTimerState++;
        }

        private void LastChangeTimerStop()
        {
            if (lastChangeTimer != null) { lastChangeTimer.Enabled = false; } // stops timer
        }

        //////////////// last change timer

        /// <summary>
        /// Starts timer that count time for new erase.
        /// </summary>
        /// <param name="interval">
        /// The interval for new erasing step.
        /// </param>
        private void RealErasingSpeedTimerStart(int interval)
        {
            realErasingSpeedTimerState = 0;
            realErasingSpeedTimer = new System.Timers.Timer();
            realErasingSpeedTimer.Interval = interval;
            realErasingSpeedTimer.Elapsed += new ElapsedEventHandler(RealErasingSpeedTimerTick); // timers tick
            realErasingSpeedTimer.Enabled = true; // starts timer
        }

        private void RealErasingSpeedTimerTick(object sender, EventArgs e)
        {
            realErasingSpeedTimerState++;
        }

        private void RealErasingSpeedTimerStop()
        {
            if (realErasingSpeedTimer != null) { realErasingSpeedTimer.Enabled = false; } // stops timer
        }

        //////////////// stop permission timer

        /// <summary>
        ///  Starts timer to countdown time for opening acess for stopButton
        /// </summary>
        private void StopPermissionTimerStart()
        {
            stopPermissionTimerState = 0;
            stopPermissionTimer = new System.Timers.Timer();
            stopPermissionTimer.Interval = 1000;
            stopPermissionTimer.Elapsed += new ElapsedEventHandler(StopPermissionTimerTick); // timers tick
            stopPermissionTimer.Enabled = true; // starts timer
        }

        private void StopPermissionTimerTick(object sender, EventArgs e)
        {
            stopPermissionTimerState++;
        }

        private void StopPermissionTimerStop()
        {
            if (stopPermissionTimer != null) { stopPermissionTimer.Enabled = false; } // stops timer
        }

        ///////////////////////////////////////// work process

        /// <summary>
        /// <see cref="workThread" />s method. Initialize start and edit text with user.
        /// </summary>
        private void Work()
        {
            if (startType == false)
            {
                Dispatcher.Invoke(new Action(() =>
                {
                    PreStartTimerStart(); // to start timer before entering the loop // TODO NORMAL look for other options
                }));
            }

            textBoxChanged = false;

            while (workState == false && stopState == false) // initiating start process
            {
                if (startType == true && textBoxChanged == true)
                {
                    workState = true; // start work

                    break;
                }
                else if (startType == false && preStartTimerState >= timeBeforeStart)
                {
                    PreStartTimerStop();

                    workState = true; // start work

                    Dispatcher.Invoke(new Action(() =>
                    {
                        textBox.IsEnabled = true;
                        textBox.Focus();
                    }));

                    break;
                }
            }


            LastChangeTimerStart();
            //int previousErasingTimerState = 0;
            StopPermissionTimerStart();

            bool realErasingSpeedTimerStartFlag = true;
            bool stopFlag = true;

            while (workState == true && stopState == false) // work in progress
            {
                if (erasingModeSwitch == true && lastChangeTimerState >= timeBeforeErasing)
                {
                    if (erasingFunction == "linear" && realErasingSpeedTimerStartFlag == true)
                    {
                        RealErasingSpeedTimerStart(erasingSpeed);
                        realErasingSpeedTimerStartFlag = false;
                    }

                    if (realErasingSpeedTimerState >= 1)
                    {
                        TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);

                        int erasingStartPoint = 0;
                        if (erasingType == "symbol")
                        {
                            erasingStartPoint = range.Text.Length - 3;
                        }

                        if (erasingStartPoint >= 0)
                        {
                            //TextPointer caret = textBox.CaretPosition;

                            Dispatcher.Invoke(new Action(() =>
                            {

                                range.Text = range.Text.Remove(erasingStartPoint);
                                textBox.CaretPosition = textBox.CaretPosition.DocumentEnd;



                                //textBox.CaretPosition = textBox.CaretPosition
                                //textBox.CaretPosition.DeleteTextInRun(2);
                                //textBox.CaretPosition = textBox.Document.ContentEnd;
                                //textBox.CaretPosition.GetInsertionPosition(LogicalDirection.Backward).DeleteTextInRun(1);
                                //textBox.CaretPosition = textBox.CaretPosition.GetPositionAtOffset(1, LogicalDirection.Forward);
                                //textBox.CaretPosition.GetInsertionPosition(LogicalDirection.Backward).DeleteTextInRun(1);
                                //textBox.CaretPosition.GetPositionAtOffset(1, LogicalDirection.Forward);
                                /*
                                textBox.CaretPosition = textBox.Document.ContentStart;
                                textBox.CaretPosition = textBox.CaretPosition.GetPositionAtOffset(erasingStartPoint, LogicalDirection.Forward);
                                */
                            }));
                        }

                        RealErasingSpeedTimerStop(); // TODO HIGH Make if?
                        realErasingSpeedTimerStartFlag = true;
                    }
                    //Erase();
                }
                if (stopPermissionTimerSwitch == true && stopPermissionTimerState >= stopPermissionTime && stopFlag == true)
                {                    
                    Dispatcher.Invoke(new Action(() =>
                    {
                        stopB.IsEnabled = true;
                    }));
                    stopFlag = false;
                }
            }
        }

        /// <summary>
        /// Show dialog with proposition to save changes if file was changed.
        /// </summary>
        /// <returns>
        /// True to continue or false to cancel saving the file. Could be used in "if".
        /// </returns>
        /// <remarks>
        /// In YES case it do the same as <see cref = "SaveFile_Executed" /> event and returns TRUE. 
        /// In NO case it do nothing and returns TRUE.
        /// In CANCEL case it do nothing and returns FALSE.
        /// </remarks>
        public bool AskToSaveIfNeedTo()
        {
            if (lastChangeAfterSave == true) // TODO NORMAL make a metod for not saved files
            {
                
                MessageBoxResult result = MessageBox.Show("Do you want to save changes?", "File NOT saved", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);

                switch (result)
                {
                    case MessageBoxResult.Yes:
                        {
                            if (activeFileFullName == "./temp.txt") // TODO NORMAL find way to use SaveAs_Executed // TODO HIGH check if it works right
                            {
                                // save file as // TODO LOW make proposition for default or last name and path
                                SaveFileDialog dialog = new SaveFileDialog();
                                dialog.Filter = "Text files | *.txt";
                                if (dialog.ShowDialog() == true) // TODO NORMAL check how does it work
                                {
                                    activeFileFullName = dialog.FileName;

                                    //fileStream = new FileStream(dialog.FileName, FileMode.Create);
                                    //TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                                    //range.Save(fileStream, DataFormats.Text);
                                    SaveToActiveFile();

                                    lastChangeAfterSave = false;
                                }
                            }
                            else
                            {
                                // save file
                                //TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                                //range.Save(fileStream, DataFormats.Text);
                                SaveToActiveFile();

                                lastChangeAfterSave = false;
                            }

                            return true;
                        }

                    case MessageBoxResult.No:
                        {
                            lastChangeAfterSave = false;

                            return true;
                        }

                    case MessageBoxResult.Cancel:
                        {
                            return false;
                        }
                }
            }
            return true;
        }
        /*
        private void SetProgramVariables() // for first time set last or default vars, then used for choosen profiles // TODO HIGH chain of files
        {
            if (File.Exists(programSettingsPath))
            {
                StringBuilder buffer = new StringBuilder(255);


                GetPrivateString("ProfileSettings", "activeProfile", null, buffer, 255, programSettingsPath); // TODO HIGH what if there is no profile with this name?

                if (buffer.ToString() != "") { profile = buffer.ToString(); }
                else { profile = "Default"; }
            }
            else { MessageBox.Show("Program settings NOT found!"); }
        }
        */


        /// <summary>
        /// Sets the profile variables from ini file.
        /// </summary>
        private void SetProfileVariables()
        {
            if (File.Exists(profilesSettingsPath))
            {
                StringBuilder buffer = new StringBuilder(255);

                
                GetPrivateString(profile, "startType", null, buffer, 255, profilesSettingsPath);

                if (buffer.ToString() == "True") { startType = true; }
                else { startType = false; }


                GetPrivateString(profile, "timeBeforeStart", null, buffer, 255, profilesSettingsPath);

                timeBeforeStart = Convert.ToInt32(buffer.ToString());


                GetPrivateString(profile, "erasingModeSwitch", null, buffer, 255, profilesSettingsPath);

                if (buffer.ToString() == "True") { erasingModeSwitch = true; }
                else { erasingModeSwitch = false; }


                GetPrivateString(profile, "timeBeforeErasing", null, buffer, 255, profilesSettingsPath);

                timeBeforeErasing = Convert.ToInt32(buffer.ToString());


                GetPrivateString(profile, "erasingType", null, buffer, 255, profilesSettingsPath);

                erasingType = buffer.ToString();


                GetPrivateString(profile, "erasingFunction", null, buffer, 255, profilesSettingsPath);

                erasingFunction = buffer.ToString();


                GetPrivateString(profile, "erasingSpeed", null, buffer, 255, profilesSettingsPath);

                erasingSpeed = Convert.ToInt32(buffer.ToString());


                GetPrivateString(profile, "stopPermissionTimerSwitch", null, buffer, 255, profilesSettingsPath);

                if (buffer.ToString() == "True")
                {
                    stopPermissionTimerSwitch = true;
                }
                else
                {
                    stopPermissionTimerSwitch = false;
                }


                GetPrivateString(profile, "stopPermissionTime", null, buffer, 255, profilesSettingsPath);

                stopPermissionTime = Convert.ToInt32(buffer.ToString());
                
                /*
                if (startType == true) { start.Content = "Start with first symbol"; }
                else { start.Content = "Start after " + timeBeforeStart + " sec"; }

                if (erasingModeSwitch == true)
                {
                    // TODO HIGH переделать таймеры?
                }

                //if (stopPermissionTimerSwitch == true) { stopB.Content = "Stop" + timeBeforeStart + " sec"; }

                */
                //statusBar.Content = "startType == " + startType.ToString() + "; erasingMode == " + erasingModeSwitch.ToString() + "; timeBeforeErasing == " + timeBeforeErasing.ToString() + "; erasingType == " + erasingType.ToString() + "; erasingFunction == " + erasingFunction.ToString(); // test
            }
            else { MessageBox.Show("Profiles settings NOT found!"); }
        }
        /*
        private bool OpenFile(string path)
        {
            if (File.Exists(path))
            {
                activeFileFullName = path;

                fileStream = new FileStream(path, FileMode.Open);
                TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
                range.Load(fileStream, DataFormats.Text);

                return true;
            }
            else
            {
                MessageBox.Show("File NOT found");

                return false;
            }

        }
        */

        /// <summary>
        /// Rewrite file in fileStream with new version.
        /// </summary>
        private void SaveToActiveFile()
        {
            if (fileStream != null)
            {
                fileStream.Close();
            }
            fileStream = new FileStream(activeFileFullName, FileMode.Create);
            TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
            fileStream.Write(Encoding.Default.GetBytes(range.Text), 0, Encoding.Default.GetBytes(range.Text).Length);
        }

        /// <summary>
        /// Handles the Closed event of the SettingsWindow window.
        /// Refreshes vareables with fresh data by using <see cref="SetProfileVariables" /> method.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="EventArgs" /> instance containing the event data.
        /// </param>
        private void SettingsWindow_Closed(object sender, EventArgs e)
        {
            SetProfileVariables();
        }


        /// <summary>
        /// Handles the Closing event of the MainWindow window.
        /// Help to correctly stop app and save all changes if need.
        /// </summary>
        /// <param name="sender">
        /// The source of the event.
        /// </param>
        /// <param name="e">
        /// The <see cref="CancelEventArgs" /> instance containing the event data.
        /// </param>
        private void Window_Closing(object sender, CancelEventArgs e)
        {
            AskToSaveIfNeedTo(); // TODO HIGH Cancel!!!!

            if (fileStream != null)
            {
                fileStream.Close();
            }
            fileStream = new FileStream(activeFileFullName, FileMode.Create);
            TextRange range = new TextRange(textBox.Document.ContentStart, textBox.Document.ContentEnd);
            fileStream.Write(Encoding.Default.GetBytes(""), 0, Encoding.Default.GetBytes("").Length);

            if (File.Exists(programSettingsPath))
            {
                WritePrivateString("ProfileSettings", "activeProfile", profile, programSettingsPath);
                WritePrivateString("OpenedFiles", "activeFile", activeFileFullName, programSettingsPath);
            }
            else { MessageBox.Show("Program settings file NOT found!"); }

            // TODO HIGH saving to temp and load
        }
    }

    /////////////////////////////////////////////////////////////////////////////////////////// my comands initialization
    public class MyCommands
    {
        static MyCommands()
        {
            Start = new RoutedCommand("Start", typeof(MainWindow));
            Stop = new RoutedCommand("Stop", typeof(MainWindow));
        }
        public static RoutedCommand Start { get; set; }
        public static RoutedCommand Stop { get; set; }
    }
}
// MessageBox.Show("" + ); // test