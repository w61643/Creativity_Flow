var searchData=
[
  ['settingslogic_11',['SettingsLogic',['../class_creativity___flow_1_1_settings_logic.html',1,'Creativity_Flow']]],
  ['settingswindow_12',['SettingsWindow',['../class_creativity___flow_1_1_settings_window.html',1,'Creativity_Flow']]]
];
