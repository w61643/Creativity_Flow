var searchData=
[
  ['main_26',['Main',['../class_creativity___flow_1_1_app.html#a1cc416a3234f545740c94824c70c1c39',1,'Creativity_Flow.App.Main()'],['../class_creativity___flow_1_1_app.html#a1cc416a3234f545740c94824c70c1c39',1,'Creativity_Flow.App.Main()']]],
  ['mainwindow_27',['MainWindow',['../class_creativity___flow_1_1_main_window.html#abe53229bd89bbcd3474b682a46bbfb5b',1,'Creativity_Flow::MainWindow']]]
];
