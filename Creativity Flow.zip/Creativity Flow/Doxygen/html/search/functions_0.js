var searchData=
[
  ['applyactivation_23',['ApplyActivation',['../class_creativity___flow_1_1_settings_logic.html#a3210f42bc1eea082e198ddbfab4d46dd',1,'Creativity_Flow::SettingsLogic']]],
  ['asktosaveifneedto_24',['AskToSaveIfNeedTo',['../class_creativity___flow_1_1_main_window.html#a680dbddef5dea3fc4646aa17403a8389',1,'Creativity_Flow::MainWindow']]]
];
